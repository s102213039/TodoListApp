# TodoListApp
TodoList with RecyclerView and FragmentViewPager

# Reference
1.ViewPager+Fragment with dynamically refresh views:
http://blog.csdn.net/chdjj/article/details/21999109
